# Working with modules

# import math module
import math
import os
os.system("cls")


# making use of a function in the math library
print("The  squre root of of 16 is ", math.sqrt(16))

# print the value of pi
print("PI is ", math.pi)


print("sin(30) = ", math.sin(math.radians(30)) )
print("sin(60) = ", math.sin(math.radians(60)))
print("sin(45) = ", math.sin(math.radians(45)))

